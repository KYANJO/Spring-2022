function y = generate(x)

    global stepsize
    y = x+stepsize.*randn(2,1);
    
end